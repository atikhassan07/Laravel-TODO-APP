<?php echo $__env->make('partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container" style="margin-top:100px">
    <div class="row">
        <?php if(session('delete')): ?>
            <span class="alert alert-danger"><?php echo e(session('delete')); ?></span>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <span class="alert alert-success"><?php echo e(session('success')); ?></span>
    <?php endif; ?>
        <div class="col-lg-8 m-auto shadow">
       

       

        <table class="table table-stripe">
            <tr>
                <th>SL NO:</th>
                <th>TODO NAME:</th>
                <th>STATUS:</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($todo->todo); ?></td>
                    <?php if($todo->status == 0): ?>
                        <td><span>In Process</span></td>
                    <?php endif; ?>
                    <?php if($todo->status == 1): ?>
                        <td><span>Work Done</span></td>
                    <?php endif; ?>
                    <?php if($todo->status == -1): ?>
                        <td><span>Late</span></td>
                    <?php endif; ?>
                    
                    <td>
                        <a href="<?php echo e(route('approve.todo',$todo->id)); ?>"><span class="badge" style="background:green;color:#fff;"> Done</span></a>
                        <a href="<?php echo e(route('cencle.todo',$todo->id)); ?>"><span class="badge" style="background:red;color:#fff;"> Late</span></a>
                        <a href="<?php echo e(route('delete.todo',$todo->id)); ?>"><span class="badge" style="background:blue;color:#fff;"> Delete</span></a>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
    </div>
<?php echo $__env->make('partial.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo-app\resources\views/todo_list.blade.php ENDPATH**/ ?>