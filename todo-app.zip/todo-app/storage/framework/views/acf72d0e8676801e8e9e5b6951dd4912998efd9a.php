<?php echo $__env->make('partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container" style="margin-top:100px">
    <div class="row">
        <div class="col-lg-4 m-auto">
            <div class="card">
                <div class="card-header">
                    <h1 class="text-center" style="font-size: 32px;">Add <b class="text-primary">TODO</b></h1>
                </div>
                <form action="<?php echo e(route('store.todo')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="add" class="mb-3"><b>Add Todo:</b></label>
                            <input type="text" name="todo" class="form-control" id="add" placeholder="Enter Your TODO">
                            <?php $__errorArgs = ['todo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn form-control" style="background: #007bff;color:#fff; font-wight:bold;">Add TODO</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('partial.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo-app\resources\views/add_todo.blade.php ENDPATH**/ ?>