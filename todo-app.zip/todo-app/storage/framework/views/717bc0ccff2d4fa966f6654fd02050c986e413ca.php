<script src="https://cdn.tailwindcss.com"></script>
      <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
      <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script>
      function onMenuToggle(e) {
  const navlinks = document.querySelector(".navLinks");
  e.name = e.name === "menu" ? "close" : "menu";
  navlinks.classList.toggle("left-[0%]");
}
</script>



</body>
</html><?php /**PATH C:\xampp\htdocs\todo-app\resources\views/partial/script.blade.php ENDPATH**/ ?>