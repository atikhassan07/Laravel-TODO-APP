<!doctype html>
<html lang="en">
@include('partial.head')
  <body>
   @include('partial.header')
   




















 @include('partial.script')
